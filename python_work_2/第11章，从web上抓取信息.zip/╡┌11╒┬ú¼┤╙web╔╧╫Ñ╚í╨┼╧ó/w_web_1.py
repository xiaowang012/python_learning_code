#使用webbrowser模块的mapIt.py，打开指定网页
# import webbrowser

# webbrowser.open('www.feisu.com')

#使用requests模块从web下载文件
import requests

res=requests.get('http://community.feisu.com/blog/understanding-fiber-loss-what-is-it-and-how-to-calculate-it.html')
print(type(res))#会产生一个Response对象
if res.status_code==requests.codes.ok:#通过判断status_code属性是否为requesets.codes.ok,如果是则请求成功。
    print('连接成功！')
#如果下载成功，则保存在Response对象的text变量中，，保存了整个网页的字符串
print(len(res.text))#获取下载的字符串的长度
print(res.text[:101])#显示前10个字符

#检查错误,通过检查Response对象的status_code属性是否为ok判断下载是否成功;还有一种方法在Response对象上调用raise_for_status()方法
#如果下载成功则什么都不做，如果下载失败则抛出异常
res=requests.get('https://m.gmw.cn/baijia/2020-07/13/1301362882.html')
try:
    res.raise_for_status()
except Exception as exc:
    print('下载失败，发生了问题:%s'%(exc))
print(res.text)#不出错则打印出下载的文件

#将下载的文件保存到硬盘

